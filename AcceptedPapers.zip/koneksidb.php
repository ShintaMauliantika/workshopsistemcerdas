<?php

$host = mysqli_connect("localhost", "root", "051299", "acceptedpapers");

?>