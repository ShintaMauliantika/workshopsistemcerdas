<?php include "header.php" ?>
    <div class="main-panel">
          <div class="col-lg-max col-md-12">
           <div class="card">
            <div class="card-header card-header-warning">
              <h4 class="card-title">Cluster Awal</h4>
              <p class="card-category">HEART FAILURE</p>
            </div>
              <?php
                include 'koneksidb.php';
                $query = mysqli_query($host, "SELECT * FROM tb_data ");
                // $qa = mysqli_query($host, "SELECT * FROM tb_clusterawal");
                $qu = mysqli_query($host, "SELECT td.*, tc.id_clusterawal FROM tb_clusterawal tc JOIN tb_data td ON td.id_data=tc.id_data");
              ?>
            <div class="card-body table-responsive">
            <!-- Modal -->
            <?php 
            $literasi = 1;
            $bool = true;
            $lit = [];
            $update_cluster = [];
            $cNumber = [];
            
            while ($bool) {
              // if($literasi == 6){
              //   $bool = false;
              // }
              ?> 
              <h1>Literasi<?= $literasi ?></h1>
              <table class="table table-striped">
                <thead class="text-warning">
                  <th>No.Data</th>
                  <th>Age</th>
                  <th>Anaemia</th>
                  <th>Creatinine Phosphokinase</th>
                  <th>Diabetes</th>
                  <th>Ejection Fraction</th>
                  <th>High Blood Pressure</th>
                  <th>Platelets</th>
                  <th>Serum Creatinine</th>
                  <th>Serum Sodium</th>
                  <th>Sex</th>
                  <th>Smoking</th>
                  <th>Time</th>
                  <th>Death Event</th>
                </thead>
                <tbody>
                <?php
                
                if($literasi == 1){
                while($data = mysqli_fetch_array($qu, MYSQLI_ASSOC)){
              ?>
                <tr>
                  <td><?php echo $data["id_data"]; ?></td>
                  <td><?php echo $data["age"];?></td>
                  <td><?php echo $data["anaemia"];?></td>
                  <td><?php echo $data["creatinine_phosphokinase"];?></td>
                  <td><?php echo $data["diabetes"];?></td>
                  <td><?php echo $data["ejection_fraction"];?></td>
                  <td><?php echo $data["high_blood_pressure"];?></td>
                  <td><?php echo $data["platelets"];?></td>
                  <td><?php echo $data["serum_creatinine"];?></td>
                  <td><?php echo $data["serum_sodium"];?></td>
                  <td><?php echo $data["sex"];?></td>
                  <td><?php echo $data["smoking"];?></td>
                  <td><?php echo $data["time"];?></td>
                  <td><?php echo $data["death_event"];?></td>
                </tr>
              <?php }}else{
                echo "<pre>";
                usort($update_cluster, function($a, $b) {
                    return $a['cluster'] <=> $b['cluster'];
                });
                
                // print_r($update_cluster);
                $qa = mysqli_query($host, "SELECT * FROM tb_clusterawal");
                $cc = [];
                
                while($dupdate = mysqli_fetch_array($qa, MYSQLI_ASSOC)){
                  $rd = search($update_cluster, 'cluster', $dupdate['id_clusterawal']);
                  $clusterID = [];
                  // print_r($rd);
                  for ($i=0; $i < count($rd); $i++) {
                    if($rd[$i]['literasi'] == $literasi - 1){
                      $clusterID[] = $rd[$i]['id_data'];
                    }
                  }
                  $res = queryFromArray($clusterID);
                  $cc[] = $res;
                ?>
                <tr>
                  <!-- <td><?php echo "<pre>"; print_r($rd) ?></td> -->
                  <td><?php echo $dupdate["id_data"]; ?></td>
                  <td><?php echo $res["age"];?></td>
                  <td><?php echo $res["anaemia"];?></td>
                  <td><?php echo $res["creatinine_phosphokinase"];?></td>
                  <td><?php echo $res["diabetes"];?></td>
                  <td><?php echo $res["ejection_fraction"];?></td>
                  <td><?php echo $res["high_blood_pressure"];?></td>
                  <td><?php echo $res["platelets"];?></td>
                  <td><?php echo $res["serum_creatinine"];?></td>
                  <td><?php echo $res["serum_sodium"];?></td>
                  <td><?php echo $res["sex"];?></td>
                  <td><?php echo $res["smoking"];?></td>
                  <td><?php echo $res["time"];?></td>
                  <td><?php echo $res["death_event"];?></td>
                </tr>
              <?php }
            
            } ?>
                </tbody>
              </table>
              <table class="table table-hover">
                <thead class="text-warning">
                <th>Centroid</th>
                <th>ID.Data</th>
                  <?php 
                    $id = 1;
                    $qa = mysqli_query($host, "SELECT * FROM tb_clusterawal");
                    while ($qd = mysqli_fetch_array($qa, MYSQLI_ASSOC)) {
                  ?>
                  <th>C<?= $id ?></th>
                  <?php $id++;} ?>
                  <th>MIN</th>
                  <?php 
                  for ($i=0; $i < $literasi; $i++) { 
                  ?>
                  <th>Cluster <?= $i+1 ?></th>
                  <?php } ?>
                  <td>Status</td>
                </thead>
                <tbody>
              <?php
                $no = 1;
                // if($literasi == 1){
                  $query = mysqli_query($host, "SELECT * FROM tb_data ");
                  $arrayCluster = [];
                  $status_cluster = [];
                while($data = mysqli_fetch_array($query, MYSQLI_ASSOC)){
              ?>
                <tr>
                <td><?php echo $no ?></td>  
                  <td><?php echo $data["id_data"]; ?></td>
                <?php 
                $n = 1;
                $qq = mysqli_query($host, "SELECT * FROM tb_clusterawal");
                $min = [];
                $index = 0;
                while ($qr = mysqli_fetch_array($qq, MYSQLI_ASSOC)) {
                    $d = mysqli_query($host, "SELECT td.* FROM tb_clusterawal tc JOIN tb_data td ON tc.id_data=td.id_data where td.id_data='$qr[id_data]'");
                    if($literasi == 1){
                    $dd = mysqli_fetch_array($d, MYSQLI_ASSOC);
                      $penghitungan = sqrt( pow(($data['age']-$dd['age']), 2) + pow(($data['anaemia']-$dd['anaemia']), 2) + pow(($data['creatinine_phosphokinase']-$dd['creatinine_phosphokinase']), 2) + pow(($data['diabetes']-$dd['diabetes']), 2) + pow(($data['ejection_fraction']-$dd['ejection_fraction']), 2) + pow(($data['high_blood_pressure']-$dd['high_blood_pressure']), 2) + pow(($data['platelets']-$dd['platelets']), 2) + pow(($data['serum_creatinine']-$dd['serum_creatinine']), 2) + pow(($data['serum_sodium']-$dd['serum_sodium']), 2) + pow(($data['sex']-$dd['sex']), 2) + pow(($data['smoking']-$dd['smoking']), 2) + pow(($data['time']-$dd['time']), 2) + pow(($data['death_event']-$dd['death_event']), 2));
                    }else{
                      $dd = $cc[$index];
                      $penghitungan = sqrt( pow(($data['age']-$dd['age']), 2) + pow(($data['anaemia']-$dd['anaemia']), 2) + pow(($data['creatinine_phosphokinase']-$dd['creatinine_phosphokinase']), 2) + pow(($data['diabetes']-$dd['diabetes']), 2) + pow(($data['ejection_fraction']-$dd['ejection_fraction']), 2) + pow(($data['high_blood_pressure']-$dd['high_blood_pressure']), 2) + pow(($data['platelets']-$dd['platelets']), 2) + pow(($data['serum_creatinine']-$dd['serum_creatinine']), 2) + pow(($data['serum_sodium']-$dd['serum_sodium']), 2) + pow(($data['sex']-$dd['sex']), 2) + pow(($data['smoking']-$dd['smoking']), 2) + pow(($data['time']-$dd['time']), 2) + pow(($data['death_event']-$dd['death_event']), 2));
                    }
                    $min[] = nilai($penghitungan);
                ?>
                  <td><?php echo nilai($penghitungan)?></td>
                  <?php $n++;$index++;} ?>
                    <td><?= min($min);?></td>
                    <?php 
                    $arrayCluster[] = array_search(min($min), $min)+1;
                    $s = array_search(min($min), $min)+1;
                    $checkCluster = [];
                  for ($z=0; $z < count($cNumber); $z++) { 
                    $checkCluster[] = $cNumber[$z][$no-1];
                  ?>
                  <td><?= $cNumber[$z][$no-1]?></td>
                  <?php }
                  
                  if(count($cNumber) == $literasi-1){
                    // echo $s;
                    // echo "<br>";
                    $checkCluster[] = $s; ?>
                  <td><?= $s ?></td>
                  <?php }
                  // echo "<pre>";
                  $array2 = checkSameValue($checkCluster) ? "1" : "0";
                  // print_r($checkCluster);
                  // print_r($array2);
                  // echo " | ";
                  if($array2 == '1'){
                    echo "<td>Selesai</td>";
                    $status_cluster[] = 1;
                  }else{
                    $status_cluster[] = 0;
                    echo "<td>Belum Selesai</td>";
                  }
                  ?>
                </tr>
              <?php 
              $update_cluster[] = ['id_data' => $data['id_data'], 'min' => min($min), 'cluster' => array_search(min($min), $min)+1, 'literasi' => $literasi];
              $no++;};
              $cNumber[] = $arrayCluster;
              if($literasi!=1){
                // echo "<pre>";
                // print_r($status_cluster);
                if(in_array("0", $status_cluster)){
                  $bool= true;
                }else{
                  $bool = false;
                }
              }
              ?>
              </tbody>
            </table>
              <?php $literasi++;} 
              // echo "<pre>";
              // print_r($cNumber);
              ?>
            </div>
           </div>
          </div>
    </div>
<?php include "footer.php"?>